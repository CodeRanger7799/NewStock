import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthCredentialService {

  constructor(private http:HttpClient) { }

  handleAuthorization(username,password) 
  {
    
   return this.http.post<any>(`http://localhost:8090/authenticate`,{username,password}).pipe(
      map(
        data =>
        {
          sessionStorage.setItem('role',data.role)
          sessionStorage.setItem('user',username)
          sessionStorage.setItem('token',`Bearer ${data.token}`)
          return data
        }
      )
    )
  }

  getSessionUsername()
  {
    return sessionStorage.getItem('user')
  }

  getSessionToken()
  {
    return sessionStorage.getItem('token')
  }
  isAdmin()
  {
    
    return (sessionStorage.getItem('role') === '[ROLE_ADMIN]')
  }

  isUser()
  {
    return (sessionStorage.getItem('role') === '[ROLE_USER]')
  }

  isLoggedIn()
  {
    return !(sessionStorage.getItem('user') === null)
  }

  isloggedout()
  {
    return (sessionStorage.getItem('user') === null)
  }

   logout()
    {
      sessionStorage.removeItem('role')
      sessionStorage.removeItem('user')
      sessionStorage.removeItem('token')
    }


}
