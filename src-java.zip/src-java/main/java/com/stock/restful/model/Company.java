package com.stock.restful.model;

import java.util.Arrays;

public class Company {
	private String companyName;
	private float turnover;
	private String ceo;
	private String boardOfDirectors;
	private String[] listings;
	private String sector;
	private String brief;
	private String code;
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Company(String companyName, float turnover, String ceo, String boardOfDirectors, String[] listings,
			String sector, String brief, String code) {
		super();
		this.companyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		this.boardOfDirectors = boardOfDirectors;
		this.listings = listings;
		this.sector = sector;
		this.brief = brief;
		this.code = code;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public float getTurnover() {
		return turnover;
	}
	public void setTurnover(float turnover) {
		this.turnover = turnover;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public String[] getListings() {
		return listings;
	}
	public void setListings(String[] listings) {
		this.listings = listings;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	@Override
	public String toString() {
		return "Company [companyName=" + companyName + ", turnover=" + turnover + ", ceo=" + ceo + ", boardOfDirectors="
				+ boardOfDirectors + ", listings=" + Arrays.toString(listings) + ", sector=" + sector + ", brief="
				+ brief + ", code=" + code + "]";
	}
	
	
}
