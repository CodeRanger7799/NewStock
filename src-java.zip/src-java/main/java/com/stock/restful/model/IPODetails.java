package com.stock.restful.model;

import java.util.Date;

public class IPODetails {
	private long id;
	private String companyName;
	private String stockExhange;
	private float pricePerShare;
	private int numberOfShares;
	private Date openingTime;
	private String remarks;
	public IPODetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IPODetails(long id, String companyName, String stockExhange, float pricePerShare, int numberOfShares,
			Date openingTime, String remarks) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.stockExhange = stockExhange;
		this.pricePerShare = pricePerShare;
		this.numberOfShares = numberOfShares;
		this.openingTime = openingTime;
		this.remarks = remarks;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getStockExhange() {
		return stockExhange;
	}
	public void setStockExhange(String stockExhange) {
		this.stockExhange = stockExhange;
	}
	public float getPricePerShare() {
		return pricePerShare;
	}
	public void setPricePerShare(float pricePerShare) {
		this.pricePerShare = pricePerShare;
	}
	public int getNumberOfShares() {
		return numberOfShares;
	}
	public void setNumberOfShares(int numberOfShares) {
		this.numberOfShares = numberOfShares;
	}
	public Date getOpeningTime() {
		return openingTime;
	}
	public void setOpeningTime(Date openingTime) {
		this.openingTime = openingTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "IPODetails [id=" + id + ", companyName=" + companyName + ", stockExhange=" + stockExhange
				+ ", pricePerShare=" + pricePerShare + ", numberOfShares=" + numberOfShares + ", openingTime="
				+ openingTime + ", remarks=" + remarks + "]";
	}
	

}
