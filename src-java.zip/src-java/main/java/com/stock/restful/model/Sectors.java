package com.stock.restful.model;

public class Sectors {
	private long id;
	private String name;
	private String brief;
	public Sectors() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Sectors(long id, String name, String brief) {
		super();
		this.id = id;
		this.name = name;
		this.brief = brief;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	@Override
	public String toString() {
		return "Sectors [id=" + id + ", name=" + name + ", brief=" + brief + "]";
	}
	

}
